# Car-Pooling-App
Carpooling reduces each person’s travels costs such as fuel costs, tolls, and the stress of driving. Carpooling is one method that can be easily instituted and can help resolve a variety of problems that continue to plague urban areas, ranging from energy demands and traffic congestion to environmental pollution.
A car-pooling system can help reduce a lot of pollution and also reduce traffic on the streets. This system also promotes healthy relation between the users as they are willing to travel together and share a vehicle, this will also help a major upcoming problem of petrol or diesel scarcity. 

![image](https://user-images.githubusercontent.com/69747262/151299953-027c8994-caa9-47c2-9592-486f1fb7c4dc.png)


https://user-images.githubusercontent.com/69747262/151300374-5f4b9fe1-a78d-4dff-80da-bcf87df5afd2.mp4

